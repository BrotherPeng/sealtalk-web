window.__sealtalk_config={
  serverUrl:"http://api.sealtalk.im",
  appkey:"n19jmcy59f1q9"
}
