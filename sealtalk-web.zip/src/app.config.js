window.__sealtalk_config={
  serverUrl:"http://api.sealtalk.im",
  appkey:"n19jmcy59f1q9"
}
// window.__sealtalk_config={
//   serverUrl:"http://api.hitalk.im",
//   appkey:"e0x9wycfx7flq",
// }
