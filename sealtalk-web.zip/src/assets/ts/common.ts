module webim {
  angular.module('webim').service('searchData', ["$q", "$http", function($q: ng.IQService, $http: ng.IHttpService) {
    var cacheData: any = {};

    this.searchContact = function(str: string) {

      var defer = $q.defer();

      var rep = {
        "data": [
          {
            "id": 0,
            "oaName": "oaName0",
            "realName": "realName0",
            "deptPathName": "部门全路径0",
            "mobilePhone": "188888880",
            "chat": "1"
          },
          {
            "id": 1,
            "oaName": "oaName1",
            "realName": "realName1",
            "deptPathName": "部门全路径1",
            "mobilePhone": "188888881",
            "chat": "1"
          },
          {
            "id": 2,
            "oaName": "oaName2",
            "realName": "realName2",
            "deptPathName": "部门全路径2",
            "mobilePhone": "188888882",
            "chat": "1"
          }
        ],
        "code": "1",
        "msg": "操作成功",
        "ctime": 1473842122761
      }

      if (cacheData[str]) {
        defer.resolve(cacheData[str]);
      } else {
        //模拟s服务器请求
        setTimeout(function() {
          cacheData[str] = {}

          defer.resolve();
        }, 2 * 1000);
      }

      return defer.promise;

    }

  }]);
}
