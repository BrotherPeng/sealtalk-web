module webim {
  var webim = angular.module('webim');

  webim.controller('organizationController', ["$scope", "organizationServer", "$state", function($scope: any, organizationServer: any, $state: ng.ui.IStateService) {

    $scope.treeOptions = {
      isLeaf: function(node: any) {
        return !node.deptName;
      },
      isSelectable: function(node: any) {
        return !node.deptName;
      },
      equality: function(node1: any, node2: any) {
        return node1 === node2;
      }
    }

    organizationServer.getList().then(function(data: any) {
      $scope.organizationList = data.department
    });


    $scope.toggleNode = function(node: any) {
      if (!node.children) {
        organizationServer.getList().then(function(data: any) {
          node.children = data.person;
          node.children = angular.copy(node.children.concat(data.department));
        });
      }
    }

    $scope.onSelection = function(node: any) {
      $state.go("main.friendinfo", { userid: node.id, groupid: 0, targetid: 0, conversationtype: 0 });
    }

  }]);

  webim.directive('organization', [function() {
    return {
      restrict: 'E',
      template: '<treecontrol class="tree-classic"' +
      ' tree-model="organizationList"' +
      ' options="treeOptions"' +
      ' on-node-toggle="toggleNode(node)"' +
      ' on-selection="onSelection(node)">' +
      '{{node.deptName||node.realName}}' +
      '</treecontrol>',
      controller: 'organizationController'
    }
  }]);

  webim.service('organizationServer', ["$q", function($q: ng.IQService) {

    this.getList = function(id: string) {
      var rep = {
        "data": {
          "person": [
            {
              "id": "0",
              "oaName": "张三",
              "realName": "张三",
              "mobilePhone": "18201252063",
              "chat": "2"
            },
            {
              "id": "1",
              "oaName": "李四",
              "realName": "李四",
              "mobilePhone": "18201252063",
              "chat": "1"
            },
            {
              "id": "2",
              "oaName": "王五",
              "realName": "王五",
              "mobilePhone": "18201252063",
              "chat": "1"
            }
          ],
          "department": [
            {
              "id": "1",
              "deptName": "设计部"
            },
            {
              "id": "2",
              "deptName": "后勤部"
            },
            {
              "id": "3",
              "deptName": "会计部"
            }
          ]
        },
        "code": "1",
        "msg": "操作成功",
        "ctime": 1473842272273
      }



      var defer = $q.defer();

      //模拟服务器异步请求
      setTimeout(function() {
        defer.resolve(rep.data);
      }, 100);


      return defer.promise;

    }


    this.searchStaff = function(name: string) {
      var rep = {
        "data": [
          {
            "id": 0,
            "oaName": "张三",
            "realName": "张三",
            "deptPathName": "",
            "mobilePhone": "188888880",
            "chat": "1"
          },
          {
            "id": 1,
            "oaName": "李四",
            "realName": "李四",
            "deptPathName": "",
            "mobilePhone": "188888881",
            "chat": "1"
          },
          {
            "id": 2,
            "oaName": "王五",
            "realName": "王五",
            "deptPathName": "",
            "mobilePhone": "188888882",
            "chat": "1"
          }
        ],
        "code": "1",
        "msg": "操作成功",
        "ctime": 1473842122761
      }

      var defer = $q.defer();

      //模拟服务器请求
      setTimeout(function() {
        defer.resolve(rep.data);
      }, 2 * 1000)

      return defer.promise;
    }

  }])

}
