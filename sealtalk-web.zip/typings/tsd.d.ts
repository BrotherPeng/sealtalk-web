/// <reference path="angular-file-upload/angular-file-upload.d.ts" />
/// <reference path="angular-ui-router/angular-ui-router.d.ts" />
/// <reference path="angularjs/angular.d.ts" />
/// <reference path="bootstrap/bootstrap.d.ts" />
/// <reference path="jquery/jquery.d.ts" />
/// <reference path="ng-file-upload/ng-file-upload.d.ts" />
